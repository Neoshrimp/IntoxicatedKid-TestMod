This is more of an workspace than an actual mod.

Installation: Download test.dll and place it to Steam\steamapps\common\LBoL\BepInEx\plugins

While in a run, press F1 to gain/lose Test Exhibit. This allows you to ignore all paths and gain 999 Firpower and Spirit.  
Press F2 to gain/lose TASBot. This will replace your draw step with playing cards on draw pile.